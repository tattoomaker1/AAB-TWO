#!/usr/bin/env bash
set -e

echo "===================================================================="
echo "  NEO Tracker - Build Signed Google Play App Bundle (.aab)"
echo "  Application ID: com.neotracker.app | Target SDK: 36 (Android 15)"
echo "===================================================================="

cd "$(dirname "$0")"

if ! command -v java >/dev/null 2>&1; then
  echo "[ERROR] Java JDK 21+ not found. Install JDK 21+ or open android/ in Android Studio."
  exit 1
fi

if [ -f "package.json" ] && command -v npm >/dev/null 2>&1; then
  if [ ! -d "node_modules" ]; then
    echo "[1/4] Installing npm dependencies..."
    npm install
  fi
  echo "[2/4] Building web assets and syncing Capacitor..."
  npm run build
  npx cap sync android
fi

if [ ! -f "android/keystore.properties" ]; then
  echo "[3/4] Creating upload release keystore for Google Play signing..."
  if [ ! -f "android/app/neotracker-upload.keystore" ]; then
    keytool -genkeypair -v \
      -keystore android/app/neotracker-upload.keystore \
      -alias neotracker \
      -keyalg RSA -keysize 2048 -validity 10000 \
      -storepass neotracker-upload-2026 -keypass neotracker-upload-2026 \
      -dname "CN=NEO Tracker, OU=Planetary Defense, O=NEO Tracker, C=US"
  fi
  cat <<EOF > android/keystore.properties
storeFile=neotracker-upload.keystore
storePassword=neotracker-upload-2026
keyAlias=neotracker
keyPassword=neotracker-upload-2026
EOF
  echo "[INFO] Saved android/app/neotracker-upload.keystore — back up this file for future Play Store updates."
else
  echo "[3/4] Using existing android/keystore.properties signing config."
fi

echo "[4/4] Building signed Android App Bundle (.aab)..."
cd android
chmod +x gradlew
./gradlew bundleRelease

echo ""
echo "SUCCESS! Upload this signed .aab file to Google Play Console:"
echo "android/app/build/outputs/bundle/release/app-release.aab"
