# NEO Tracker - Android Release & Google Play Console Package
**Application ID:** `com.neotracker.app`  
**Target SDK:** `API 36 (Android 15)`  
**Min SDK:** `API 24 (Android 7.0+)`  
**Release Version:** `v1.0.0 (Build 1)`  
**Google Play Category:** `Education / Science & Astronomy`  
**Content Rating:** `PEGI 3 / Everyone (3+)`

---

## Why Play Console Rejects `.zip` and `.apk` Files (And How to Get Your `.aab`)

Google Play Console's **Upload app bundles** screen only accepts a **signed `.aab` (Android App Bundle)** file:
- You **cannot** rename a `.zip` to `.aab`, and Google Play **does not accept `.apk`** for new releases.
- **If your `.zip` came from PWABuilder:** Your `.aab` file is **already inside the `.zip`**! Right-click the `.zip` -> **Extract All...**, open the extracted folder, and upload **ONLY the `.aab` file** (for example `app-release-bundle.aab`, NOT the `.zip` and NOT the `.apk`). You can also drop the `.zip` into the **`.ZIP -> .AAB Extractor`** inside the NEO Tracker Play Store Hub to extract the `.aab` in 1 click.
- **If your `.zip` is `neo-tracker-android-bundle.zip` (this source project):** It contains the uncompiled Android Studio project (`android/`), which must be compiled and signed into `app-release.aab` using one of the 3 options below.

---

## Option 1: Free Cloud Build via GitHub Actions (No Android Studio Needed)
1. Extract this `.zip` into a folder on your PC.
2. Upload/push the folder to a GitHub repository (keep the `.github/workflows/build-playstore-bundle.yml` file).
3. Open your GitHub repository -> **Actions** tab -> **Build Google Play Release Bundle (.aab)** -> **Run workflow**.
4. When it finishes (~2 minutes), download the `neo-tracker-playstore-aab` artifact `.zip`, extract **`neo-tracker-release.aab`**, and drop **`neo-tracker-release.aab`** directly into Google Play Console!

---

## Option 2: Windows 1-Click Script (`build-release-bundle.bat`)
Requires **Java JDK 21+** and **Android SDK** (installed automatically if you have Android Studio):
1. Extract this `.zip` into a folder (for example `C:\neo-tracker`).
2. Double-click **`build-release-bundle.bat`**.
3. It automatically generates your release upload keystore (`android\app\neotracker-upload.keystore`), builds & signs the bundle, and opens File Explorer directly to:
   `android\app\build\outputs\bundle\release\app-release.aab`
4. Drag that `.aab` file into Google Play Console -> **Create internal testing release** -> **App bundles**.

---

## Option 3: Android Studio Visual Wizard (Windows / macOS)
1. Open **Android Studio** -> **Open** -> select the **`android`** folder inside the extracted project.
2. Wait for Gradle sync to finish.
3. Click **Build** > **Generate Signed Bundle / APK...**
4. Select **Android App Bundle** -> click **Next**.
5. Click **Create new...** to create a `.jks` keystore file (remember your passwords!) -> click **Next**.
6. Choose **release** build variant -> click **Create** / **Finish**.
7. Upload the generated `android\app\build\outputs\bundle\release\app-release.aab` to Google Play Console.
