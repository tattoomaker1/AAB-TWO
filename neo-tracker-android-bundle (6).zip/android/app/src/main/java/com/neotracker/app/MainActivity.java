package com.neotracker.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
