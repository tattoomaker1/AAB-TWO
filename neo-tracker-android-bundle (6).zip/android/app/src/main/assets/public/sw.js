// Service Worker for NEO Tracker Offline Telemetry Cache
const CACHE_NAME = 'neo-tracker-v2';
const TELEMETRY_CACHE_NAME = 'nasa-telemetry-v2';

const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/favicon.ico',
];

// Install: precache essential shell assets
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(STATIC_ASSETS).catch((err) => {
        console.warn('[SW] Pre-caching static assets failed:', err);
      });
    }).then(() => self.skipWaiting())
  );
});

// Activate: clean up outdated cache buckets
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames
          .filter((name) => name !== CACHE_NAME && name !== TELEMETRY_CACHE_NAME)
          .map((name) => caches.delete(name))
      );
    }).then(() => self.clients.claim())
  );
});

// Fetch: Network-First with cache fallback for NASA telemetry API
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // Handle NASA API requests
  if (url.origin === 'https://api.nasa.gov' && url.pathname.includes('/neo/rest/v1/feed')) {
    event.respondWith(
      fetch(event.request)
        .then(async (networkResponse) => {
          // If valid response, clone and update telemetry cache
          if (networkResponse && networkResponse.status === 200) {
            const responseToCache = networkResponse.clone();
            caches.open(TELEMETRY_CACHE_NAME).then((cache) => {
              cache.put(event.request, responseToCache);
            });
            return networkResponse;
          }
          // If rate limited (429) or server error, serve cached telemetry if available
          if (networkResponse && (networkResponse.status === 429 || networkResponse.status >= 500)) {
            const cachedResponse = await caches.match(event.request);
            if (cachedResponse) return cachedResponse;
            const telemetryCache = await caches.open(TELEMETRY_CACHE_NAME);
            const keys = await telemetryCache.keys();
            if (keys.length > 0) {
              const fallbackResponse = await telemetryCache.match(keys[keys.length - 1]);
              if (fallbackResponse) return fallbackResponse;
            }
          }
          return networkResponse;
        })
        .catch(async () => {
          // Network failed (offline or network error) -> attempt cache match
          const cachedResponse = await caches.match(event.request);
          if (cachedResponse) {
            return cachedResponse;
          }
          // If exact URL isn't cached, try matching any cached NASA feed response
          const telemetryCache = await caches.open(TELEMETRY_CACHE_NAME);
          const keys = await telemetryCache.keys();
          if (keys.length > 0) {
            const fallbackResponse = await telemetryCache.match(keys[keys.length - 1]);
            if (fallbackResponse) return fallbackResponse;
          }
          return new Response(
            JSON.stringify({ error: 'Offline and no cached telemetry available' }),
            { status: 503, headers: { 'Content-Type': 'application/json' } }
          );
        })
    );
    return;
  }

  // Handle local app assets (Network-First for code/html, stale-while-revalidate for static files)
  if (event.request.method === 'GET' && (url.origin === self.location.origin)) {
    event.respondWith(
      fetch(event.request)
        .then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200 && networkResponse.type === 'basic') {
            const responseToCache = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(event.request, responseToCache);
            });
          }
          return networkResponse;
        })
        .catch(async () => {
          const cachedResponse = await caches.match(event.request);
          if (cachedResponse) return cachedResponse;
          if (url.pathname === '/' || url.pathname.endsWith('.html')) {
            return caches.match('/');
          }
          return new Response('', { status: 404 });
        })
    );
  }
});
