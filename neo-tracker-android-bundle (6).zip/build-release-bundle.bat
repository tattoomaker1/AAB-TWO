@echo off
setlocal enabledelayedexpansion
echo ====================================================================
echo   NEO Tracker - Build Signed Google Play App Bundle (.aab)
echo   Application ID: com.neotracker.app  ^|  Target SDK: 36 (Android 15)
echo ====================================================================
echo.

cd /d "%~dp0"

where java >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Java JDK 21+ was not found in PATH.
    echo Please install JDK 21+ or open the "android" folder in Android Studio
    echo and use: Build ^> Generate Signed Bundle / APK... ^> Android App Bundle.
    pause
    exit /b 1
)

if exist "package.json" (
    where npm >nul 2>nul
    if not errorlevel 1 (
        if not exist "node_modules" (
            echo [1/4] Installing npm dependencies...
            call npm install
        )
        echo [2/4] Building web assets and syncing Capacitor Android project...
        call npm run build
        call npx cap sync android
    )
)

if not exist "android\keystore.properties" (
    echo [3/4] Creating upload release keystore for Google Play signing...
    if not exist "android\app\neotracker-upload.keystore" (
        keytool -genkeypair -v -keystore "android\app\neotracker-upload.keystore" -alias neotracker -keyalg RSA -keysize 2048 -validity 10000 -storepass neotracker-upload-2026 -keypass neotracker-upload-2026 -dname "CN=NEO Tracker, OU=Planetary Defense, O=NEO Tracker, C=US"
    )
    (
        echo storeFile=neotracker-upload.keystore
        echo storePassword=neotracker-upload-2026
        echo keyAlias=neotracker
        echo keyPassword=neotracker-upload-2026
    ) > "android\keystore.properties"
    echo [INFO] Keystore saved to android\app\neotracker-upload.keystore. Keep this file safe for future app updates!
) else (
    echo [3/4] Found existing android\keystore.properties signing config.
)

echo [4/4] Building signed Android App Bundle (.aab)...
cd android
call gradlew.bat bundleRelease
if errorlevel 1 (
    echo.
    echo [ERROR] Gradle build failed. Make sure Android SDK is installed (via Android Studio)
    echo and ANDROID_HOME / local.properties points to your Android SDK folder.
    pause
    exit /b 1
)

echo.
echo ====================================================================
echo   SUCCESS! Ready-to-upload Google Play App Bundle created at:
echo   android\app\build\outputs\bundle\release\app-release.aab
echo ====================================================================
echo Upload ONLY that .aab file to Google Play Console (not .zip or .apk).
if exist "app\build\outputs\bundle\release\app-release.aab" (
    explorer /select,"app\build\outputs\bundle\release\app-release.aab"
)
pause
