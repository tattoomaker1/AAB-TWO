#!/usr/bin/env bash
set -euo pipefail

echo "===================================================================="
echo "  NEO Tracker - Generate Signed Android App Bundle (.aab)"
echo "  Application ID: com.neotracker.app | Target SDK: 36 (Android 15)"
echo "===================================================================="

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ANDROID_DIR="${ROOT_DIR}/android"
OUTPUT_AAB="${ANDROID_DIR}/app/build/outputs/bundle/release/app-release.aab"

if [ ! -d "${ANDROID_DIR}" ]; then
  echo "[ERROR] Android project directory not found at ${ANDROID_DIR}"
  exit 1
fi

if ! command -v java >/dev/null 2>&1; then
  echo "[ERROR] Java JDK 21+ is required to run Gradle 'bundleRelease'."
  exit 1
fi

# Sync web build into Capacitor Android assets if Node/npm are available
if [ -f "${ROOT_DIR}/package.json" ] && command -v npm >/dev/null 2>&1; then
  cd "${ROOT_DIR}"
  if [ ! -d "node_modules" ]; then
    echo "[1/4] Installing npm dependencies..."
    npm install
  fi
  echo "[2/4] Building web assets and syncing Capacitor Android project..."
  npm run build
  npx cap sync android
fi

# Ensure release signing keystore is configured so Play Console accepts the .aab
if [ ! -f "${ANDROID_DIR}/keystore.properties" ]; then
  echo "[3/4] Generating upload release keystore for Google Play signing..."
  KEYSTORE_FILE="${ANDROID_DIR}/app/neotracker-upload.keystore"
  if [ ! -f "${KEYSTORE_FILE}" ]; then
    keytool -genkeypair -v \
      -keystore "${KEYSTORE_FILE}" \
      -alias neotracker \
      -keyalg RSA -keysize 2048 -validity 10000 \
      -storepass neotracker-upload-2026 -keypass neotracker-upload-2026 \
      -dname "CN=NEO Tracker, OU=Planetary Defense, O=NEO Tracker, C=US"
  fi
  cat <<EOF > "${ANDROID_DIR}/keystore.properties"
storeFile=neotracker-upload.keystore
storePassword=neotracker-upload-2026
keyAlias=neotracker
keyPassword=neotracker-upload-2026
EOF
  echo "[INFO] Upload keystore created at android/app/neotracker-upload.keystore"
else
  echo "[3/4] Using existing android/keystore.properties signing configuration."
fi

echo "[4/4] Running Gradle ':app:bundleRelease'..."
cd "${ANDROID_DIR}"
chmod +x gradlew
./gradlew bundleRelease

if [ -f "${OUTPUT_AAB}" ]; then
  cp "${OUTPUT_AAB}" "${ROOT_DIR}/neo-tracker-release.aab"
  echo ""
  echo "===================================================================="
  echo "  SUCCESS! Android App Bundle (.aab) generated:"
  echo "  - android/app/build/outputs/bundle/release/app-release.aab"
  echo "  - neo-tracker-release.aab (copied to project root)"
  echo "===================================================================="
  echo "Upload the .aab file directly to Google Play Console (not .zip or .apk)."
else
  echo "[ERROR] Gradle finished, but ${OUTPUT_AAB} was not found."
  exit 1
fi
